# BurgerPremium – hero kártya + kosár integráció

Ez a verzió már tartalmazza:

- Unsplash-ről származó prémium burger képet a hero kártyában
- a „Truffle Smash Burger” külön termékként szerepel a `burgers.json`-ban
- ha a hero kártyára kattintasz:
  - hozzáadja a burgert a kosárhoz (`useCart().addItem(topBurger)`)
  - automatikusan átvisz a `/checkout` oldalra, így a kosár „előugrik”

A projekt indítása:

```bash
npm install
npm run dev
```

Majd böngészőben `http://localhost:5173`.

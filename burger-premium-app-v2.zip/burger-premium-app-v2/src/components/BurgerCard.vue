<template>
  <article class="card">
    <div class="card__image" :style="{ backgroundImage: 'url(' + burger.image + ')' }"></div>
    <div class="card__body">
      <h3 class="card__title">{{ burger.name }}</h3>
      <p class="card__desc">{{ burger.description }}</p>
      <div class="card__footer">
        <span class="card__price">{{ burger.price.toFixed(0) }} Ft</span>
        <button class="card__button" @click="add">
          Add to cart
        </button>
      </div>
      <ul class="card__tags">
        <li v-for="tag in burger.tags" :key="tag" class="card__tag">{{ tag }}</li>
      </ul>
    </div>
  </article>
</template>

<script>
import useCart from '../store/cart'

export default {
  name: 'BurgerCard',
  props: {
    burger: {
      type: Object,
      required: true
    }
  },
  setup(props) {
    const { addItem } = useCart()
    function add() {
      addItem(props.burger)
    }
    return { add }
  }
}
</script>

<style scoped>
.card {
  background: radial-gradient(circle at top left, rgba(249, 115, 22, 0.15), transparent),
    #020617;
  border-radius: 1rem;
  overflow: hidden;
  border: 1px solid rgba(148, 163, 184, 0.35);
  display: flex;
  flex-direction: column;
  box-shadow: 0 18px 45px rgba(15, 23, 42, 0.7);
}

.card__image {
  height: 180px;
  background-size: cover;
  background-position: center;
}

.card__body {
  padding: 1.2rem 1.3rem 1.3rem;
  display: flex;
  flex-direction: column;
  gap: 0.55rem;
}

.card__title {
  margin: 0;
  font-size: 1.05rem;
}

.card__desc {
  margin: 0;
  font-size: 0.85rem;
  color: #9ca3af;
}

.card__footer {
  margin-top: 0.4rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.card__price {
  font-weight: 700;
  color: #fbbf24;
}

.card__button {
  padding: 0.35rem 0.9rem;
  border-radius: 999px;
  border: none;
  background: linear-gradient(135deg, #f97316, #ea580c);
  color: #111827;
  cursor: pointer;
  font-size: 0.8rem;
  font-weight: 600;
}

.card__tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  list-style: none;
  padding: 0;
  margin: 0.4rem 0 0;
}

.card__tag {
  font-size: 0.7rem;
  padding: 0.15rem 0.45rem;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, 0.6);
}
</style>

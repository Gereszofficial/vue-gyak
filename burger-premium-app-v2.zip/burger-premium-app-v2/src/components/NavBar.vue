<template>
  <header class="nav">
    <div class="nav__left">
      <div class="nav__logo">BURGER<span>PREMIUM</span></div>
      <nav class="nav__links">
        <RouterLink to="/" class="nav__link">Home</RouterLink>
        <RouterLink to="/menu" class="nav__link">Menu</RouterLink>
        <RouterLink to="/about" class="nav__link">About</RouterLink>
      </nav>
    </div>
    <RouterLink to="/checkout" class="nav__cart">
      <span class="nav__cart-label">Cart</span>
      <span class="nav__cart-count" v-if="itemCount > 0">{{ itemCount }}</span>
    </RouterLink>
  </header>
</template>

<script>
import { RouterLink } from 'vue-router'
import useCart from '../store/cart'

export default {
  name: 'NavBar',
  components: { RouterLink },
  setup() {
    const { itemCount } = useCart()
    return { itemCount }
  }
}
</script>

<style scoped>
.nav {
  height: 72px;
  padding: 0 3rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #050509;
  border-bottom: 1px solid rgba(148, 163, 184, 0.2);
  position: sticky;
  top: 0;
  z-index: 10;
}

.nav__left {
  display: flex;
  align-items: center;
  gap: 3rem;
}

.nav__logo {
  font-weight: 800;
  letter-spacing: 0.12em;
  font-size: 1rem;
}

.nav__logo span {
  color: #f97316;
}

.nav__links {
  display: flex;
  gap: 1.5rem;
  font-size: 0.9rem;
}

.nav__link {
  color: #9ca3af;
}

.nav__link.router-link-active {
  color: #f9fafb;
}

.nav__cart {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.35rem 0.9rem;
  border-radius: 999px;
  border: 1px solid rgba(249, 115, 22, 0.6);
  background: radial-gradient(circle at top left, rgba(249, 115, 22, 0.35), transparent),
    #020617;
  cursor: pointer;
}

.nav__cart-label {
  font-size: 0.85rem;
}

.nav__cart-count {
  min-width: 20px;
  height: 20px;
  border-radius: 999px;
  background: #f97316;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  font-weight: 700;
}
</style>

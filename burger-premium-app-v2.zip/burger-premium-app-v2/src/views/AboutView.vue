<template>
  <section class="about">
    <div class="about__inner">
      <h2>About BurgerPremium</h2>
      <p>
        BurgerPremium is a demo burger ordering experience that blends ideas from popular
        food delivery apps into one premium looking interface. It has a hero landing page,
        filterable card based menu and a simple cart + checkout flow.
      </p>
      <p>
        All products are fake and no real payment is processed – it is only meant as a
        learning project for Vue 3, Vue Router, JSON data handling and shared cart state.
      </p>
    </div>
  </section>
</template>

<script>
export default {
  name: 'AboutView'
}
</script>

<style scoped>
.about {
  padding: 3rem 3.5rem 3.5rem;
}

.about__inner {
  max-width: 640px;
}

.about__inner h2 {
  margin: 0;
  font-size: 1.9rem;
}

.about__inner p {
  margin-top: 0.8rem;
  color: #9ca3af;
  line-height: 1.7;
}
@media (max-width: 900px) {
  .about {
    padding: 2.5rem 1.5rem 3rem;
  }
}
</style>

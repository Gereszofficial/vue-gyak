<template>
  <section class="checkout">
    <div class="checkout__card">
      <h2>Your order</h2>
      <p v-if="!items.length" class="checkout__empty">
        Your cart is empty. Head over to the menu and add something tasty!
      </p>

      <ul v-else class="checkout__list">
        <li v-for="item in items" :key="item.id" class="checkout__item">
          <div class="checkout__info">
            <p class="checkout__name">{{ item.name }}</p>
            <p class="checkout__meta">{{ item.price.toFixed(0) }} Ft • x{{ item.qty }}</p>
          </div>
          <div class="checkout__actions">
            <button @click="decreaseItem(item.id)">−</button>
            <button @click="addItem(item)">+</button>
            <button class="checkout__remove" @click="removeItem(item.id)">Remove</button>
          </div>
        </li>
      </ul>

      <div v-if="items.length" class="checkout__summary">
        <div class="checkout__row">
          <span>Subtotal</span>
          <strong>{{ totalPrice.toFixed(0) }} Ft</strong>
        </div>
        <div class="checkout__row checkout__row--muted">
          <span>Delivery</span>
          <span>Free</span>
        </div>
        <div class="checkout__row checkout__row--highlight">
          <span>Total</span>
          <strong>{{ totalPrice.toFixed(0) }} Ft</strong>
        </div>
        <button class="checkout__button" @click="fakePay">
          Place order
        </button>
        <p v-if="placed" class="checkout__success">
          🎉 Order placed! (demo only, no real payment)
        </p>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import useCart from '../store/cart'

const { state, addItem, decreaseItem, removeItem, totalPrice, clearCart } = useCart()
const items = state.items
const placed = ref(false)

function fakePay() {
  if (!items.length) return
  placed.value = true
  clearCart()
  setTimeout(() => {
    placed.value = false
  }, 3000)
}
</script>

<style scoped>
.checkout {
  padding: 3rem 1.5rem 3.5rem;
  display: flex;
  justify-content: center;
}

.checkout__card {
  width: 100%;
  max-width: 640px;
  background: #020617;
  border-radius: 1.25rem;
  border: 1px solid rgba(148, 163, 184, 0.4);
  padding: 2rem 2.3rem 2.4rem;
  box-shadow: 0 22px 50px rgba(15, 23, 42, 0.9);
}

.checkout__card h2 {
  margin: 0;
  font-size: 1.5rem;
}

.checkout__empty {
  margin-top: 1.3rem;
  color: #9ca3af;
}

.checkout__list {
  margin: 1.4rem 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.9rem;
}

.checkout__item {
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.checkout__name {
  margin: 0;
}

.checkout__meta {
  margin: 0.2rem 0 0;
  font-size: 0.8rem;
  color: #9ca3af;
}

.checkout__actions {
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.checkout__actions button {
  padding: 0.2rem 0.45rem;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  background: transparent;
  color: #e5e7eb;
  font-size: 0.8rem;
  cursor: pointer;
}

.checkout__remove {
  border-color: rgba(248, 113, 113, 0.8);
}

.checkout__summary {
  margin-top: 1.7rem;
  border-top: 1px solid rgba(31, 41, 55, 0.9);
  padding-top: 1.3rem;
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}

.checkout__row {
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
}

.checkout__row--muted span {
  color: #9ca3af;
}

.checkout__row--highlight {
  margin-top: 0.4rem;
}

.checkout__button {
  margin-top: 1.1rem;
  padding: 0.7rem 1.4rem;
  border-radius: 999px;
  border: none;
  background: linear-gradient(135deg, #22c55e, #4ade80);
  color: #022c22;
  font-weight: 700;
  cursor: pointer;
}

.checkout__success {
  margin-top: 0.8rem;
  font-size: 0.9rem;
  color: #bbf7d0;
}
</style>

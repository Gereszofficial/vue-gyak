<template>
  <section class="hero">
    <div class="hero__content">
      <p class="hero__eyebrow">PREMIUM CRAFTED BURGERS</p>
      <h1>Next-level burger experience in every single bite.</h1>
      <p class="hero__text">
        Build your perfect combo, explore chef curated specials and order in a few taps.
        BurgerPremium brings the feel of the big burger apps into one clean interface.
      </p>
      <div class="hero__actions">
        <RouterLink to="/menu">
          <button class="hero__primary">Browse menu</button>
        </RouterLink>
        <RouterLink to="/about" class="hero__secondary">How it works</RouterLink>
      </div>
      <div class="hero__stats">
        <div>
          <strong>35+</strong>
          <span>Signature burgers</span>
        </div>
        <div>
          <strong>10k+</strong>
          <span>Happy foodies</span>
        </div>
        <div>
          <strong>24/7</strong>
          <span>Ordering</span>
        </div>
      </div>
    </div>
    <div class="hero__visual">
      <div class="hero__glow"></div>
      <button class="hero__card" @click="addTopBurger">
        <p class="hero__card-title">TOP PICK RIGHT NOW</p>
        <div class="hero__card-main">
          <img
            class="hero__image"
            :src="topBurger.image"
            :alt="topBurger.name"
          />
          <div class="hero__card-text">
            <p class="hero__card-burger">{{ topBurger.name }}</p>
            <p class="hero__card-meta">
              Smoked cheddar • Truffle mayo • Brioche
            </p>
            <p class="hero__card-price">{{ topBurger.price.toFixed(0) }} Ft</p>
            <span class="hero__card-cta">Tap to add to cart →</span>
          </div>
        </div>
      </button>
    </div>
  </section>
</template>

<script>
import { RouterLink, useRouter } from 'vue-router'
import useCart from '../store/cart'

export default {
  name: 'HomeView',
  components: { RouterLink },
  setup() {
    const router = useRouter()
    const { addItem } = useCart()

    const topBurger = {
      id: 7,
      name: 'Truffle Smash Burger',
      description: 'Smoked cheddar, truffle mayo and brioche bun.',
      price: 3890,
      image: 'https://images.unsplash.com/photo-1551782450-a2132b4ba21d'
    }

    function addTopBurger() {
      addItem(topBurger)
      router.push('/checkout')
    }

    return { topBurger, addTopBurger }
  }
}
</script>

<style scoped>
.hero {
  display: grid;
  grid-template-columns: minmax(0, 1.3fr) minmax(0, 1fr);
  padding: 4rem 3.5rem 3.5rem;
  gap: 3rem;
}

.hero__content h1 {
  font-size: 2.8rem;
  line-height: 1.1;
  margin: 0.4rem 0 1rem;
}

.hero__eyebrow {
  letter-spacing: 0.2em;
  font-size: 0.78rem;
  text-transform: uppercase;
  color: #f97316;
}

.hero__text {
  max-width: 520px;
  color: #9ca3af;
  font-size: 0.95rem;
}

.hero__actions {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-top: 1.5rem;
}

.hero__primary {
  padding: 0.7rem 1.6rem;
  border-radius: 999px;
  border: none;
  background: linear-gradient(135deg, #f97316, #facc15);
  color: #111827;
  font-weight: 700;
  cursor: pointer;
}

.hero__secondary {
  font-size: 0.88rem;
  color: #e5e7eb;
}

.hero__stats {
  display: flex;
  gap: 2.5rem;
  margin-top: 2.5rem;
  font-size: 0.85rem;
}

.hero__stats strong {
  display: block;
  font-size: 1.4rem;
}

.hero__stats span {
  color: #9ca3af;
}

.hero__visual {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.hero__glow {
  position: absolute;
  inset: 5%;
  background: radial-gradient(circle at top, rgba(249, 115, 22, 0.5), transparent 60%),
    radial-gradient(circle at bottom, rgba(56, 189, 248, 0.35), transparent 60%);
  filter: blur(18px);
  opacity: 0.9;
}

.hero__card {
  position: relative;
  padding: 1.4rem 1.6rem;
  border-radius: 1.6rem;
  background: rgba(15, 23, 42, 0.96);
  border: 1px solid rgba(148, 163, 184, 0.8);
  box-shadow: 0 22px 60px rgba(15, 23, 42, 0.95);
  backdrop-filter: blur(18px);
  max-width: 420px;
  color: #e5e7eb;
  text-align: left;
  cursor: pointer;
}

.hero__card-title {
  margin: 0;
  font-size: 0.78rem;
  text-transform: uppercase;
  letter-spacing: 0.18em;
  color: #9ca3af;
}

.hero__card-main {
  display: flex;
  gap: 1rem;
  margin-top: 0.9rem;
  align-items: center;
}

.hero__image {
  width: 96px;
  height: 96px;
  border-radius: 999px;
  object-fit: cover;
  border: 2px solid rgba(148, 163, 184, 0.9);
}

.hero__card-text {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
}

.hero__card-burger {
  margin: 0;
  font-size: 1.1rem;
  font-weight: 700;
}

.hero__card-meta {
  margin: 0;
  font-size: 0.85rem;
  color: #cbd5f5;
}

.hero__card-price {
  margin: 0.25rem 0 0;
  font-weight: 700;
  color: #fbbf24;
  font-size: 0.95rem;
}

.hero__card-cta {
  margin-top: 0.35rem;
  font-size: 0.78rem;
  color: #38bdf8;
}

@media (max-width: 900px) {
  .hero {
    grid-template-columns: 1fr;
    padding: 2.5rem 1.5rem 3rem;
  }
  .hero__visual {
    order: -1;
  }
}
</style>

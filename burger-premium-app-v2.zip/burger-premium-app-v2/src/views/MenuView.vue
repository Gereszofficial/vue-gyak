<template>
  <section class="menu">
    <header class="menu__header">
      <h2>Build your feast</h2>
      <p>Pick from chef crafted burgers, sides and drinks.</p>
    </header>

    <div class="menu__filters">
      <button
        v-for="filter in filters"
        :key="filter"
        class="menu__chip"
        :class="{ 'menu__chip--active': activeFilter === filter }"
        @click="activeFilter = filter"
      >
        {{ filter }}
      </button>
    </div>

    <section class="menu__grid">
      <BurgerCard
        v-for="burger in filteredBurgers"
        :key="burger.id"
        :burger="burger"
      />
    </section>
  </section>
</template>

<script>
import BurgerCard from '../components/BurgerCard.vue'
import burgers from '../data/burgers.json'

export default {
  name: 'MenuView',
  components: { BurgerCard },
  data() {
    return {
      burgers,
      filters: ['All', 'Beef', 'Chicken', 'Veggie', 'Spicy', 'Premium'],
      activeFilter: 'All'
    }
  },
  computed: {
    filteredBurgers() {
      if (this.activeFilter === 'All') return this.burgers
      return this.burgers.filter((b) => b.tags.includes(this.activeFilter))
    }
  }
}
</script>

<style scoped>
.menu {
  padding: 3rem 3.5rem 3.5rem;
}

.menu__header h2 {
  margin: 0;
  font-size: 2rem;
}

.menu__header p {
  margin: 0.4rem 0 0;
  color: #9ca3af;
}

.menu__filters {
  margin-top: 1.8rem;
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

.menu__chip {
  padding: 0.35rem 0.9rem;
  border-radius: 999px;
  border: 1px solid rgba(148, 163, 184, 0.6);
  background: transparent;
  color: #e5e7eb;
  font-size: 0.8rem;
  cursor: pointer;
}

.menu__chip--active {
  background: #f97316;
  border-color: #f97316;
  color: #111827;
}

.menu__grid {
  margin-top: 2rem;
  display: grid;
  gap: 1.7rem;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
}
@media (max-width: 900px) {
  .menu {
    padding: 2.5rem 1.5rem 3rem;
  }
}
</style>

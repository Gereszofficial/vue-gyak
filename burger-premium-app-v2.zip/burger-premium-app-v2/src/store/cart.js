import { reactive, computed } from 'vue'

const state = reactive({
  items: []
})

function addItem(product) {
  const existing = state.items.find((i) => i.id === product.id)
  if (existing) {
    existing.qty += 1
  } else {
    state.items.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      qty: 1
    })
  }
}

function removeItem(id) {
  const index = state.items.findIndex((i) => i.id === id)
  if (index !== -1) {
    state.items.splice(index, 1)
  }
}

function decreaseItem(id) {
  const existing = state.items.find((i) => i.id === id)
  if (!existing) return
  if (existing.qty <= 1) {
    removeItem(id)
  } else {
    existing.qty -= 1
  }
}

function clearCart() {
  state.items.splice(0, state.items.length)
}

const itemCount = computed(() =>
  state.items.reduce((sum, item) => sum + item.qty, 0)
)

const totalPrice = computed(() =>
  state.items.reduce((sum, item) => sum + item.qty * item.price, 0)
)

export default function useCart() {
  return {
    state,
    addItem,
    removeItem,
    decreaseItem,
    clearCart,
    itemCount,
    totalPrice
  }
}

<template>
  <div class="app">
    <NavBar />
    <main class="app__main">
      <RouterView />
    </main>
  </div>
</template>

<script>
import { RouterView } from 'vue-router'
import NavBar from './components/NavBar.vue'

export default {
  name: 'App',
  components: {
    NavBar,
    RouterView
  }
}
</script>

<style>
.app__main {
  min-height: calc(100vh - 72px);
}
</style>

<template>
  <nav class="nav">
    <div class="logo">PHOTOSNAP</div>
    <ul class="links">
      <li>STORIES</li>
      <li>FEATURES</li>
      <li>PRICING</li>
    </ul>
    <button class="invite">GET AN INVITE</button>
  </nav>
</template>

<script>
export default { name:'NavBar' }
</script>

<style scoped>
.nav {
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:20px 40px;
  background:white;
  border-bottom:1px solid #ddd;
}
.logo { font-weight:bold; }
.links { display:flex; gap:20px; list-style:none; }
.invite {
  background:black;
  color:white;
  padding:10px 20px;
  border:none;
  cursor:pointer;
}
</style>
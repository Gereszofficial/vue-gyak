<template>
  <section class="hero">
    <div class="left">
      <h1>CREATE AND SHARE YOUR PHOTO STORIES.</h1>
      <p>Photosnap is a platform for photographers and visual storytellers. We make it easy to share photos, tell stories and connect with others.</p>
      <button class="get">GET AN INVITE →</button>
    </div>
    <div class="right"></div>
  </section>
</template>

<script>
export default { name:'HeroSection' }
</script>

<style scoped>
.hero {
  display:flex;
  height:500px;
}
.left {
  flex:1;
  background:black;
  color:white;
  padding:80px 60px;
  display:flex;
  flex-direction:column;
  gap:20px;
}
.right {
  flex:1;
  background:url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee') center/cover;
}
.get {
  background:none;
  border:none;
  color:white;
  font-weight:bold;
  cursor:pointer;
}
</style>
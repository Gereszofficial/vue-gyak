<template>
  <section>
    <header class="gallery__header">
      <h2>Latest stories</h2>
      <p>Loaded from a local JSON file and rendered as cards.</p>
    </header>
    <CardGrid :stories="stories" @open="openStory" />
    <div v-if="selected" class="modal" @click.self="selected = null">
      <div class="modal__inner">
        <h3>{{ selected.title }}</h3>
        <p class="modal__meta">by {{ selected.author }} • {{ selected.date }}</p>
        <p class="modal__body">{{ selected.body }}</p>
        <button class="modal__close" @click="selected = null">Close</button>
      </div>
    </div>
  </section>
</template>

<script>
import CardGrid from '../components/CardGrid.vue'
import storiesJson from '../data/stories.json'

export default {
  name: 'GalleryView',
  components: { CardGrid },
  data() {
    return {
      stories: storiesJson,
      selected: null
    }
  },
  methods: {
    openStory(story) {
      this.selected = story
    }
  }
}
</script>

<style scoped>
.gallery__header {
  padding: 2.5rem 3rem 1rem;
}

.gallery__header h2 {
  margin: 0;
  font-size: 1.6rem;
}

.gallery__header p {
  margin-top: 0.4rem;
  color: #6b7280;
}

.modal {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal__inner {
  background: #ffffff;
  padding: 2rem 2.5rem;
  border-radius: 0.5rem;
  max-width: 540px;
  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.4);
}

.modal__meta {
  margin-top: 0.5rem;
  color: #6b7280;
}

.modal__body {
  margin-top: 1rem;
  line-height: 1.6;
}

.modal__close {
  margin-top: 1.5rem;
  padding: 0.4rem 1.2rem;
  border-radius: 4px;
  border: none;
  cursor: pointer;
}
</style>

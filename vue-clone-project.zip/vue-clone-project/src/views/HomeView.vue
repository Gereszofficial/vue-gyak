<template>
  <section class="hero">
    <div class="hero__left">
      <div class="hero__gradient"></div>
      <div class="hero__content">
        <h1>CREATE AND SHARE YOUR PHOTO STORIES.</h1>
        <p>
          Photosnap Clone is a practice project built with Vue 3. It mimics the
          look and feel of the Photosnap marketing page while loading stories
          from JSON.
        </p>
        <RouterLink to="/stories">
          <button class="hero__button">
            GET AN INVITE →
          </button>
        </RouterLink>
      </div>
    </div>
    <div class="hero__right"></div>
  </section>
</template>

<script>
import { RouterLink } from 'vue-router'

export default {
  name: 'HomeView',
  components: { RouterLink }
}
</script>

<style scoped>
.hero {
  display: grid;
  grid-template-columns: 1.1fr 1fr;
  min-height: calc(100vh - 64px);
}

.hero__left {
  position: relative;
  background: #000000;
  color: #ffffff;
  display: flex;
  align-items: center;
}

.hero__gradient {
  position: absolute;
  left: 0;
  top: 20%;
  bottom: 20%;
  width: 6px;
  background: linear-gradient(180deg, #ff8a00, #e52e71, #9b5cff);
}

.hero__content {
  padding: 3rem 4rem;
  max-width: 480px;
}

.hero__content h1 {
  font-size: 2.3rem;
  letter-spacing: 0.12em;
  text-transform: uppercase;
}

.hero__content p {
  margin-top: 1.5rem;
  color: #d1d5db;
  line-height: 1.7;
}

.hero__button {
  margin-top: 2rem;
  background: none;
  border: none;
  color: #ffffff;
  font-size: 0.9rem;
  letter-spacing: 0.15em;
  cursor: pointer;
}

.hero__right {
  background-image: url('https://images.unsplash.com/photo-1500534314211-0a24cd03f2c0');
  background-size: cover;
  background-position: center;
}
</style>

<template>
  <section class="about">
    <div class="about__inner">
      <h2>About this project</h2>
      <p>
        This is a Vue 3 + Vite practice project that visually clones the hero
        section of the Photosnap marketing website. It also demonstrates
        navigation with Vue Router and card based list rendering from JSON.
      </p>
      <p>
        The goal of the assignment was to pick any public website, reproduce its
        look-and-feel as closely as possible, and implement JSON data handling,
        navigation and reusable components.
      </p>
    </div>
  </section>
</template>

<script>
export default {
  name: 'AboutView'
}
</script>

<style scoped>
.about {
  padding: 3rem 3rem 4rem;
}

.about__inner {
  max-width: 640px;
}

.about__inner h2 {
  margin-top: 0;
  font-size: 1.7rem;
}

.about__inner p {
  margin-top: 0.8rem;
  color: #4b5563;
  line-height: 1.7;
}
</style>

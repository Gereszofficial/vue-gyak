<template>
  <div>
    <NavBar />
    <main>
      <RouterView />
    </main>
  </div>
</template>

<script>
import { RouterView } from 'vue-router'
import NavBar from './components/NavBar.vue'

export default {
  name: 'App',
  components: {
    NavBar,
    RouterView
  }
}
</script>

<style>
main {
  min-height: calc(100vh - 64px);
}
</style>

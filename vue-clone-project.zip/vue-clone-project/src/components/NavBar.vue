<template>
  <header class="nav">
    <div class="nav__logo">
      <span class="nav__icon"></span>
      <span class="nav__brand">PHOTOSNAP</span>
    </div>
    <nav class="nav__links">
      <RouterLink to="/stories" class="nav__link">STORIES</RouterLink>
      <RouterLink to="/" class="nav__link">FEATURES</RouterLink>
      <RouterLink to="/about" class="nav__link">ABOUT</RouterLink>
    </nav>
    <RouterLink to="/stories">
      <button class="nav__cta">GET AN INVITE</button>
    </RouterLink>
  </header>
</template>

<script>
import { RouterLink } from 'vue-router'

export default {
  name: 'NavBar',
  components: { RouterLink }
}
</script>

<style scoped>
.nav {
  height: 64px;
  background: #ffffff;
  border-bottom: 1px solid #e5e7eb;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 3rem;
}

.nav__logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 700;
  letter-spacing: 0.15em;
  font-size: 0.9rem;
}

.nav__icon {
  width: 18px;
  height: 18px;
  background: linear-gradient(135deg, #ff8a00, #e52e71);
  border-radius: 4px;
}

.nav__links {
  display: flex;
  gap: 2rem;
  font-size: 0.85rem;
  letter-spacing: 0.15em;
}

.nav__link {
  color: #6b7280;
}

.nav__link.router-link-active {
  color: #111827;
}

.nav__cta {
  padding: 0.6rem 1.6rem;
  background: #000000;
  color: #ffffff;
  border: none;
  font-size: 0.8rem;
  letter-spacing: 0.15em;
  cursor: pointer;
}
</style>

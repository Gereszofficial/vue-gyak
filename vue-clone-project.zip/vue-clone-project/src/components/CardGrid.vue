<template>
  <section class="grid">
    <article
      v-for="story in stories"
      :key="story.id"
      class="grid__card"
    >
      <div
        class="grid__image"
        :style="{ backgroundImage: 'url(' + story.image + ')' }"
      ></div>
      <div class="grid__body">
        <h3 class="grid__title">{{ story.title }}</h3>
        <p class="grid__meta">by {{ story.author }} • {{ story.date }}</p>
        <p class="grid__excerpt">{{ story.excerpt }}</p>
        <button class="grid__button" @click="$emit('open', story)">
          VIEW STORY →
        </button>
      </div>
    </article>
  </section>
</template>

<script>
export default {
  name: 'CardGrid',
  props: {
    stories: {
      type: Array,
      required: true
    }
  }
}
</script>

<style scoped>
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1.5rem;
  padding: 2rem 3rem 3rem;
}

.grid__card {
  background: #ffffff;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 10px 25px rgba(15, 23, 42, 0.08);
  display: flex;
  flex-direction: column;
}

.grid__image {
  height: 180px;
  background-size: cover;
  background-position: center;
}

.grid__body {
  padding: 1.25rem 1.5rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}

.grid__title {
  margin: 0;
  font-size: 1.1rem;
}

.grid__meta {
  margin: 0;
  font-size: 0.8rem;
  color: #6b7280;
}

.grid__excerpt {
  margin-top: 0.5rem;
  font-size: 0.9rem;
  color: #4b5563;
  flex: 1;
}

.grid__button {
  margin-top: 0.75rem;
  align-self: flex-start;
  background: none;
  border: none;
  font-size: 0.8rem;
  letter-spacing: 0.15em;
  cursor: pointer;
}
</style>

# Photosnap klón – Vue 3 + Vite beadandó

Ez a projekt egy **Photosnap** marketing oldalhoz hasonló, egyszerű klón, amelyet **Vue 3 + Vite** felhasználásával készítettünk.

A feladat követelményei:
- tetszőleges weboldal kinézetének minél pontosabb lemásolása (stílus + működés),
- kártyás, listás megjelenítés,
- JSON adat feldolgozás (lokális fájlból),
- navigáció (több oldal / nézet).

## 1. Kiinduló oldal

Inspiráció: **Photosnap** landing page  
(pl. Frontend Mentor – Photosnap multi-page website challange)

A projekt a felső navigációt és a fő nyitó „hero” szekciót próbálja visszaadni:
- bal oldalt fekete sáv szöveggel,
- jobb oldalt nagy fotó,
- fölötte fehér navigációs sáv „PHOTOSNAP”, menüpontokkal, „GET AN INVITE” gombbal.

## 2. Projekt létrehozása

A projekt Vite-tel és Vue 3 sablonnal készült:

```bash
npm create vite@latest photosnap-style-clone -- --template vue
cd photosnap-style-clone
npm install
```

Ezután került be:
- `vue-router` a navigációhoz,
- globális stílus fájl (`src/assets.css`).

Telepítés:

```bash
npm install vue-router
```

## 3. Főbb mappák és fájlok

```
src/
  main.js
  App.vue
  assets.css
  router/
    index.js
  components/
    NavBar.vue
    CardGrid.vue
  views/
    HomeView.vue
    GalleryView.vue
    AboutView.vue
  data/
    stories.json
```

### 3.1. `main.js`

- Betölti az `App.vue`-t,
- regisztrálja a Vue Routert,
- behúzza a globális CSS-t.

### 3.2. `router/index.js`

Három útvonalat definiál:

- `/` – `HomeView` (hero szekció, Photosnap klón),
- `/stories` – `GalleryView` (kártyás lista, JSON-ból),
- `/about` – `AboutView` (projekt leírás).

### 3.3. `NavBar.vue`

- Felső navigációs sáv:
  - logó (színes négyzet + PHOTOSNAP felirat),
  - menüpontok: STORIES, FEATURES, ABOUT,
  - jobb oldalt „GET AN INVITE” gomb.
- A menüpontok `RouterLink` komponenseket használnak.

### 3.4. `HomeView.vue`

- A Photosnap-hez hasonló hero:
  - bal oldalt fekete háttér, nagy fehér cím: „CREATE AND SHARE YOUR PHOTO STORIES.”,
  - szöveg leírással,
  - „GET AN INVITE →” gomb, ami a `/stories` oldalra visz,
  - bal szélén színátmenetes függőleges csík,
  - jobb oldalt háttérkép (Unsplash fotó).

### 3.5. `GalleryView.vue` + `CardGrid.vue`

- A `GalleryView`:
  - betölti a `src/data/stories.json` fájlt importtal,
  - átadja a tömböt a `CardGrid` komponensnek,
  - kezeli a kiválasztott kártyát egy egyszerű modal ablakban.

- A `CardGrid`:
  - rácsos (`grid`) elrendezés,
  - minden elem egy kártya:
    - kép (background-image),
    - cím, szerző, dátum,
    - rövid leírás,
    - „VIEW STORY →” gomb.
  - A gomb `open` eseményt lő ki a szülő felé (`@open`).

- A modal:
  - teljes képernyős áttetsző overlay,
  - középen fehér doboz,
  - részletesebb szöveggel,
  - „Close” gombbal.

### 3.6. `stories.json`

Egyszerű lokális JSON tömb:

```json
[
  {
    "id": 1,
    "title": "The Mountains at Dawn",
    "author": "Lena Hart",
    "date": "2024-05-01",
    "excerpt": "...",
    "body": "...",
    "image": "https://images.unsplash.com/..."
  },
  ...
]
```

A `GalleryView.vue` ezt importálja:

```js
import storiesJson from '../data/stories.json'

export default {
  data() {
    return {
      stories: storiesJson
    }
  }
}
```

## 4. Stílus

A stílus a Photosnap oldal hangulatát követi:

- sok fehér + fekete, nagy kontraszt,
- nagy betűméretű hero cím,
- kis betűs, nagy betűközű menüpontok,
- kártyákon árnyék (box-shadow),
- Unsplash képek illusztrációként.

A responsivitás alap szinten megvan (rács auto-fill), de mobilra még tovább finomítható.

## 5. Futtatás

```bash
npm install
npm run dev
```

Majd böngészőben:

- `http://localhost:5173/` – főoldal (hero),
- `http://localhost:5173/stories` – JSON-ból betöltött kártyás lista,
- `http://localhost:5173/about` – projekt leírás.

## 6. Összefoglalás

A projekt teljesíti a kiírt követelményeket:

- ✅ tetszőleges weboldal (Photosnap) vizuális klónja,
- ✅ Vue 3 + Vite keretrendszer,
- ✅ navigáció több oldallal (Vue Router),
- ✅ JSON adat feldolgozása lokális fájlból,
- ✅ kártyás, grid alapú listás megjelenítés,
- ✅ külön komponensek (NavBar, CardGrid, nézetek).

GitHub-ra feltöltve ez a projekt egy az egyben beadandóként használható.

<template>
  <div id="app">
    <!-- Navigációs sáv -->
    <Navbar />
    <!-- Itt jelennek meg az útvonalak tartalmai -->
    <main class="container">
      <router-view />
    </main>
  </div>
</template>

<script>
import Navbar from './components/Navbar.vue'

export default {
  name: 'App',
  components: {
    Navbar,
  },
}
</script>

<style>
:root { font-family: Inter, system-ui, Avenir, Helvetica, Arial, sans-serif; }
body { margin: 0; }
.container { padding: 24px; }
</style>

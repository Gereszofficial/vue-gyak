# Vue Router Navbar Projekt

Gyors indítás:

```bash
npm install
npm run dev
```

Build:
```bash
npm run build
npm run preview
```

Struktúra:
```
index.html
src/
  main.js
  App.vue
  router/index.js
  components/Navbar.vue
  views/{Home.vue, Books.vue, Contact.vue}
vite.config.js
package.json
```

import { defineStore } from 'pinia'
import axios from 'axios'

export const useItemsStore = defineStore('items', {
  state: () => ({
    items: [],
    loading: false,
    error: null,
  }),
  actions: {
    async fetchItems() {
      this.loading = true
      this.error = null
      try {
        const res = await axios.get('http://localhost:3000/items')
        this.items = res.data
      } catch (err) {
        this.error = err?.message || 'Hiba történt az adatok betöltésekor.'
      } finally {
        this.loading = false
      }
    },
  },
})

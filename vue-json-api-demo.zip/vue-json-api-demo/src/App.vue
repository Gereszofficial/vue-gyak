<template>
  <div class="min-h-screen flex flex-col">
    <nav class="bg-gray-200 px-6 py-3 flex space-x-4 shadow">
      <RouterLink to="/" class="text-blue-600 hover:underline">
        Főoldal
      </RouterLink>
      <RouterLink to="/adatok" class="text-blue-600 hover:underline">
        Adatok
      </RouterLink>
    </nav>

    <main class="flex-1">
      <RouterView />
    </main>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

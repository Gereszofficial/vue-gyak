# Vue json-server demo

## Telepítés

```bash
npm install
```

## Frontend fejlesztő szerver

```bash
npm run dev
```

## json-server indítása (külön terminálban)

```bash
npx json-server --watch db.json --port 3000
```
